#ifndef AI_AITARGET_H
#define AI_AITARGET_H

#ifdef EA_PRAGMA_ONCE_SUPPORTED
#pragma once
#endif

#include "Speed/Indep/Libs/Support/Utility/FastMem.h"
#include "Speed/Indep/Libs/Support/Utility/UCOM.h"
#include "Speed/Indep/Libs/Support/Utility/UTypes.h"
#include "Speed/Indep/Src/Interfaces/Simables/IAI.h"
#include "Speed/Indep/Src/Interfaces/Simables/ISimable.h"
#include "Speed/Indep/Src/Interfaces/Simables/IVehicle.h"
#include "Speed/Indep/bWare/Inc/bList.hpp"

#include <types.h>

// total size: 0x40
class AITarget : public bTNode<AITarget> {
  public:
    static bool CanAquire(const ISimable *who);
    static void Register(ISimable *who);
    static void UnRegister(ISimable *who);
    static void Track(const ISimable *who);
    static void TrackAll();

    void *operator new(size_t size) {
        return gFastMem.Alloc(size, nullptr);
    }

    void operator delete(void *mem, size_t size) {
        if (mem) {
            return gFastMem.Free(mem, size, nullptr);
        }
    }

    AITarget(ISimable *owner);
    void Clear();
    void Aquire(ISimable *target);
    void Aquire(const UMath::Vector3 &position);
    void Aquire(const UMath::Vector3 &position, const UMath::Vector3 &direction);
    void Aquire(const AITarget *aitarget);
    bool IsTarget(const AITarget *aitarget) const;
    float GetSpeed() const;
    const UMath::Vector3 &GetLinearVelocity() const;
    void TrackInternal();

    virtual ~AITarget();

    ISimable *GetSimable() const {
        return mTargetSimable;
    }

    const UMath::Vector3 &GetPosition() const {
        return mTargetPosition;
    }

    const UMath::Vector3 &GetDirection() const {
        return mTargetDirection;
    }

    void GetForwardVector(UMath::Vector3 &dir) const {
        dir = mTargetDirection;
    }

    bool IsValid() const {
        return mValid;
    }

    bool IsSimable() const {
        return mTargetSimable != nullptr;
    }

    float GetDistTo() const {
        return mDistTo;
    }

    const UMath::Vector3 &GetDirTo() const {
        return mDirTo;
    }

    template <typename T> bool QueryInterface(T **out) {
        if (mTargetSimable) {
            return mTargetSimable->QueryInterface(out);
        }
        *out = nullptr;
        return false;
    }

    bool IsTarget(const UTL::COM::IUnknown *object) const {
        return UTL::COM::ComparePtr(mTargetSimable, object);
    }

  private:
    ISimable *mOwner;                         // offset 0x8, size 0x4
    ALIGN_16 UMath::Vector3 mTargetPosition;  // offset 0xC, size 0xC
    ISimable *mTargetSimable;                 // offset 0x18, size 0x4
    ALIGN_16 UMath::Vector3 mTargetDirection; // offset 0x1C, size 0xC
    bool mValid;                              // offset 0x28, size 0x1
    ALIGN_16 UMath::Vector3 mDirTo;           // offset 0x2C, size 0xC
    float mDistTo;                            // offset 0x38, size 0x4
};

#endif
