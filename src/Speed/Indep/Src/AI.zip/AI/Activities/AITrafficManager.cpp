#include "Speed/Indep/Src/AI/activities/AITrafficManager.hpp"
#include "Speed/Indep/Libs/Support/Utility/UMath.h"
#include "Speed/Indep/Src/AI/AIVehicle.h"
#include "Speed/Indep/Src/Gameplay/GManager.h"
#include "Speed/Indep/Src/Gameplay/GRaceStatus.h"
#include "Speed/Indep/Src/Generated/AttribSys/Classes/trafficpattern.h"
#include "Speed/Indep/Src/Generated/Messages/MSetTrafficSpeed.h"
#include "Speed/Indep/Src/Input/ActionQueue.h"
#include "Speed/Indep/Src/Misc/Config.h"
#include "Speed/Indep/Src/Input/ActionRef.h"
#include "Speed/Indep/Src/Interfaces/ITaskable.h"
#include "Speed/Indep/Src/Interfaces/SimActivities/ICopMgr.h"
#include "Speed/Indep/Src/Interfaces/SimActivities/INIS.h"
#include "Speed/Indep/Src/Interfaces/SimActivities/ITrafficCenter.h"
#include "Speed/Indep/Src/Interfaces/SimActivities/ITrafficMgr.h"
#include "Speed/Indep/Src/Interfaces/SimActivities/IVehicleCache.h"
#include "Speed/Indep/Src/Interfaces/Simables/IVehicle.h"
#include "Speed/Indep/Src/Main/AttribSupport.h"
#include "Speed/Indep/Src/Misc/Profiler.hpp"
#include "Speed/Indep/Src/Misc/Table.hpp"
#include "Speed/Indep/Src/Physics/PVehicle.h"
#include "Speed/Indep/Src/Sim/SimActivity.h"
#include "Speed/Indep/Src/Sim/Simulation.h"
#include "Speed/Indep/Src/World/TrackPath.hpp"
#include "Speed/Indep/Src/World/WCollisionMgr.h"
#include "Speed/Indep/Tools/Inc/ConversionUtil.hpp"
#include "Speed/Indep/bWare/Inc/Strings.hpp"
#include "Speed/Indep/bWare/Inc/bWare.hpp"

#include <algorithm>

UTL::COM::Factory<Sim::Param, Sim::IActivity, UCrc32>::Prototype _AITrafficManager("AITrafficManager", AITrafficManager::Construct);

// Functionally matching
// https://decomp.me/scratch/qvQEg
AITrafficManager::AITrafficManager(Sim::Param params)
    : Sim::Activity(2),       //
      ITrafficMgr(this),      //
      IVehicleCache(this),    //
      mSpawnIdx(0),           //
      mOncommingChance(0.5f), //
      mVehicles(),            //
      mPatternMap(),          //
      mNewInstanceTimer(0),   //
      mNav(),                 //
      mPattern((Attrib::Collection *)nullptr, 0, nullptr) {
    MakeDebugable(DBG_AI);
    bMemSet(mPatternTimer, 0, sizeof(mPatternTimer));
    mNewInstanceTimer = 0;
    // default
    SetTrafficPattern(0xeec2271a);
    mVehicles.clear();
    mTask = AddTask("AITrafficManager", 0.5f, 0.5f, Sim::TASK_FRAME_VARIABLE);
    Sim::ProfileTask(mTask, "AITrafficManager");
    mActionQ = new ActionQueue(0, 0x98c7a2f5, "AITrafficManager", false);
    // trafficpattern
    const Attrib::Class *patternclass = Attrib::Database::Get().GetClass(0x20d08342);
    if (patternclass) {
        mPatternMap.clear();
        mPatternMap.reserve(patternclass->GetNumCollections());
        Attrib::Key cKey = patternclass->GetFirstCollection();

        while (cKey != 0) {
            Attrib::Gen::trafficpattern pattern(cKey, 0, nullptr);
            const char *name = pattern.CollectionName();

            PatternKey key;
            key.BHash = bStringHash(name);
            key.CollectionKey = cKey;
            mPatternMap.insert(std::upper_bound(mPatternMap.begin(), mPatternMap.end(), key), key);

            cKey = patternclass->GetNextCollection(cKey);
        }
    }
}

AITrafficManager::~AITrafficManager() {
    RemoveTask(mTask);
    if (mActionQ) {
        delete mActionQ;
        mActionQ = nullptr;
    }
}

Sim::IActivity *AITrafficManager::Construct(Sim::Param params) {
    if (SkipFE && SkipFEDisableTraffic) {
        return nullptr;
    }
    return new AITrafficManager(Sim::Param(params));
}

eVehicleCacheResult AITrafficManager::OnQueryVehicleCache(const IVehicle *removethis, const IVehicleCache *whosasking) const {
    if (!IsAttached(removethis)) {
        return VCR_DONTCARE;
    }

    if (whosasking == this) {
        if (removethis->IsActive()) {
            return VCR_WANT;
        }
        if (removethis->IsLoading()) {
            return VCR_WANT;
        }
        return VCR_DONTCARE;
    }

    if (ComparePtr(whosasking, INIS::Get())) {
        return removethis->IsActive() ? VCR_WANT : VCR_DONTCARE;
    }

    if (ComparePtr(whosasking, ICopMgr::Get())) {
        return removethis->IsActive() ? VCR_WANT : VCR_DONTCARE;
    }

    if (GRaceStatus::Exists() && whosasking == &GRaceStatus::Get()) {
        return VCR_DONTCARE;
    }

    if (GManager::Exists() && whosasking == &GManager::Get()) {
        return VCR_DONTCARE;
    }

    return VCR_WANT;
}

void AITrafficManager::OnRemovedVehicleCache(IVehicle *ivehicle) {}

void AITrafficManager::OnAttached(IAttachable *pOther) {
    IVehicle *ivehicle;
    if (pOther->QueryInterface(&ivehicle)) {
        mVehicles.push_back(ivehicle);
    }
    Sim::Activity::OnAttached(pOther);
}

void AITrafficManager::OnDetached(IAttachable *pOther) {
    IVehicle *ivehicle;
    if (pOther->QueryInterface(&ivehicle)) {
        TrafficList::iterator iter = std::find(mVehicles.begin(), mVehicles.end(), ivehicle);
        if (iter != mVehicles.end()) {
            mVehicles.erase(iter);
        }
    }
    Sim::Activity::OnDetached(pOther);
}

struct TypeCounter {
    Attrib::Key Key;
    bool ActiveOnly;
    unsigned int Count;

  public:
    TypeCounter(Attrib::Key key, bool active_only) : Key(key), ActiveOnly(active_only), Count(0) {}

    void operator()(IVehicle *vehicle) {
        if (!ActiveOnly || vehicle->IsActive()) {
            if (vehicle->GetVehicleAttributes().GetCollection() == Key) {
                Count++;
            }
        }
    }
};

Attrib::Key AITrafficManager::NextSpawn() {
    unsigned int num_types = mPattern.Num_Vehicles();
    if (num_types == 0) {
        return 0;
    }
    unsigned int max_types = UMath::Min(num_types, 10U);
    Attrib::Key key = 0;
    for (unsigned int i = 0; i < max_types && key == 0; mSpawnIdx++, i++) {
        mSpawnIdx %= max_types;
        const TrafficPatternRecord &record = mPattern.Vehicles(mSpawnIdx);
        if (mPatternTimer[mSpawnIdx] > record.Rate && record.Rate > 0.0f) {
            TypeCounter t = std::for_each(mVehicles.begin(), mVehicles.end(), TypeCounter(record.Vehicle.GetCollectionKey(), true));
            if (t.Count < record.MaxInstances || record.MaxInstances == 0) {
                unsigned int max_traffic = mVehicles.size() + 10 - IVehicle::Count(VEHICLE_ALL);
                if (record.Percent == 0 || t.Count < UMath::Max(1U, max_traffic * record.Percent / 100)) {
                    key = record.Vehicle.GetCollectionKey();
                }
            }
        }
    }
    return key;
}

IVehicle *AITrafficManager::GetAvailableTrafficVehicle(Attrib::Key key, bool makenew) {
    if (key == 0) {
        return nullptr;
    }

    for (TrafficList::const_iterator iter = mVehicles.begin(); iter != mVehicles.end(); ++iter) {
        IVehicle *ivehicle = *iter;
        if ((!ivehicle->IsActive() || ivehicle->IsLoading()) && ivehicle->GetVehicleKey() == key) {
            return ivehicle;
        }
    }
    if (!makenew) {
        return nullptr;
    }
    UMath::Vector3 initialVec = {0.0f, 0.0f, 1.0f};
    UMath::Vector3 initialPos = {0.0f, 0.0f, 0.0f};
    VehicleParams params(this, DRIVER_TRAFFIC, key, initialVec, initialPos, 0, nullptr, 0);
    ISimable *isimable = UTL::COM::Factory<Sim::Param, ISimable, UCrc32>::CreateInstance("PVehicle", params);
    if (isimable) {
        static_cast<IActivity *>(this)->Attach(isimable);
        IVehicle *ivehicle;
        if (isimable->QueryInterface(&ivehicle)) {
            ivehicle->GetAIVehiclePtr()->UnSpawn();
            mNewInstanceTimer = 0.0f;
            return ivehicle;
        }
    }
    return nullptr;
}

bool AITrafficManager::SpawnTraffic() {
    if (!mPattern.IsValid()) {
        return false;
    }

    if (!NeedsTraffic()) {
        return false;
    }

    if (!FindSpawnPoint(mNav)) {
        return false;
    }

    Attrib::Key key = NextSpawn();
    if (key == 0) {
        return false;
    }

    IVehicle *availableVehicle = GetAvailableTrafficVehicle(key, mNewInstanceTimer > mPattern.SpawnTime(0));
    if (availableVehicle == nullptr) {
        return false;
    }

    if (availableVehicle->IsLoading()) {
        return false;
    }

    IVehicleAI *ivehicleAI = availableVehicle->GetAIVehiclePtr();
    if (!ivehicleAI->ResetVehicleToRoadNav(&mNav)) {
        return false;
    }

    ivehicleAI->SetSpawned();
    availableVehicle->Activate();

    ITrafficAI *itv;
    if (availableVehicle->QueryInterface(&itv)) {
        float start_speed = UMath::Min(mPattern.SpeedStreet(0), mPattern.SpeedHighway(0));
        itv->StartDriving(MPH2MPS(start_speed) * 0.75f);
    }

    MSetTrafficSpeed ai_msg(mPattern.SpeedStreet(0), mPattern.SpeedHighway(0), false);
    ai_msg.SetID(availableVehicle->GetSimable()->GetWorldID());
    ai_msg.Post("AIAction");

    Attrib::Key vehicle_key = availableVehicle->GetVehicleKey();
    unsigned int num_types = mPattern.Num_Vehicles();
    for (unsigned int i = 0; i < num_types && i < 10; i++) {
        const TrafficPatternRecord &record = mPattern.Vehicles(i);
        if (vehicle_key == record.Vehicle.GetCollectionKey()) {
            mPatternTimer[i] = 0.0f;
        }
    }

    return true;
}

bool AITrafficManager::NeedsTraffic() const {
    int inactive_count = 0;
    for (TrafficList::const_iterator iter = mVehicles.begin(); iter != mVehicles.end(); ++iter) {
        IVehicle *ivehicle = *iter;
        if (!ivehicle->IsActive() && !ivehicle->IsLoading()) {
            inactive_count++;
        }
    }
    int active_count = IVehicle::Count(VEHICLE_ALL);
    return (unsigned int)(active_count - inactive_count) < 10;
}

void AITrafficManager::UpdateDebug() {
    while (!mActionQ->IsEmpty()) {
        ActionRef aRef = mActionQ->GetAction();
        aRef.ID();
        mActionQ->PopAction();
    }
}

static bool RandomSortTCDir = false;

static bool RandomSortTC(ITrafficCenter *c0, ITrafficCenter *c1) {
    if (RandomSortTCDir) {
        return c0 < c1;
    }
    return c1 < c0;
}

void AITrafficManager::SetTrafficPattern(Attrib::Key pattern_key) {
    if (pattern_key == mPattern.GetCollection()) {
        return;
    }
    mPattern = Attrib::Gen::trafficpattern(pattern_key, 0, nullptr);
    bMemSet(mPatternTimer, 0, sizeof(mPatternTimer));

    unsigned int num_types = mPattern.Num_Vehicles();
    for (unsigned int i = 0; i < num_types && i < 10; i++) {
        const TrafficPatternRecord &record = mPattern.Vehicles(i);
        mPatternTimer[i] = record.Rate * bRandom(1.0f);
    }
}

bool AITrafficManager::FindCollisions(const UMath::Vector3 &spawnpoint) const {
    float worldHeight;
    if (!WCollisionMgr(0, 3).GetWorldHeightAtPointRigorous(spawnpoint, worldHeight, nullptr)) {
        return true;
    }

    for (ITrafficCenter::List::const_iterator iter = ITrafficCenter::GetList().begin(); iter != ITrafficCenter::GetList().end(); iter++) {
        UMath::Matrix4 basis;
        UMath::Vector3 velocity;
        ITrafficCenter *center = *iter;
        if (center->GetTrafficBasis(basis, velocity)) {
            float distsq = UMath::DistanceSquarexz(UMath::Vector4To3(basis.v3), spawnpoint);
            if (distsq < 22500.0f) {
                return true;
            }
        }
    }
    const IVehicle::List &vehicles = IVehicle::GetList(VEHICLE_ALL);
    for (IVehicle::List::const_iterator iter = vehicles.begin(); iter != vehicles.end(); iter++) {
        IVehicle *vehicle = *iter;
        if (vehicle->IsActive()) {
            float distsq = UMath::DistanceSquarexz(vehicle->GetPosition(), spawnpoint);
            if (distsq < 400.0f) {
                return true;
            }
        }
    }
    return false;
}

bool AITrafficManager::CheckRace(const WRoadNav &nav) const {
    if (!GRaceStatus::Exists()) {
        return true;
    }
    GRaceStatus &race = GRaceStatus::Get();
    if (race.GetPlayMode() != GRaceStatus::kPlayMode_Racing) {
        return true;
    }
    GRaceParameters *params = race.GetRaceParameters();
    if (!params || !params->HasFinishLine()) {
        return true;
    }
    const WRoadSegment *seg = nav.GetSegment();
    if (seg && seg->IsInRace()) {
        return true;
    }
    return false;
}

bool AITrafficManager::FindSpawnPoint(WRoadNav &nav) const {
    RandomSortTCDir = !RandomSortTCDir;
    ITrafficCenter::Sort(RandomSortTC);
    nav.Reset();
    const ITrafficCenter::List &traffic_centers = ITrafficCenter::GetList();

    for (ITrafficCenter::List::const_iterator iter = traffic_centers.begin(); iter != traffic_centers.end(); ++iter) {
        UMath::Matrix4 basis;
        UMath::Vector3 velocity;
        ITrafficCenter *center = *iter;
        if (!center->GetTrafficBasis(basis, velocity)) {
            continue;
        }
        const UMath::Vector3 &position = UMath::Vector4To3(basis.v3);

        UMath::Vector3 direction = UMath::Vector4To3(basis.v2);
        // float angle = DEG2ANGLE((bRandom(2.0f) - 1.0f) * 45.0f);
        float angle = (bRandom(2.0f) - 1.0f) * 0.125f; // TODO
        UMath::Matrix4 rotation;
        UMath::SetYRot(rotation, angle);
        UMath::Rotate(direction, rotation, direction);

        float offset = (bRandom(2.0f) - 1.0f) * 50.0f;
        float camera_speed = UMath::Dot(velocity, direction);
        float time_offset = offset + 200.0f + UMath::Max(camera_speed, 0.0f);
        // float distance = time_offset; // TODO
        UMath::Vector3 spawnpoint;
        UMath::ScaleAdd(direction, time_offset, position, spawnpoint);

        float t = UMath::Ramp(camera_speed, 0.0f, 50.0f);
        float oncomming_chance = UMath::Lerp(1.0f, 0.5f, t);
        if (bRandom(1.0f) <= oncomming_chance) {
            UMath::Negate(direction);
        }

        nav.InitAtPoint(spawnpoint, direction, false, 1.0f);
        if (!nav.IsValid() || !nav.CanTrafficSpawn() || !CheckRace(nav)) {
            continue;
        }
        UMath::Vector3 nav_point = nav.GetPosition();
        if (!FindCollisions(nav_point)) {
            return true;
        }
    }
    return false;
}

// UNSOLVED
bool AITrafficManager::ChoosePattern() {
    mOncommingChance = 0.5f;

    // huh
    if (mPatternMap.size() < 0) {
        int pattern_idx = mPatternMap.size() - 1;
        PatternKey &key = mPatternMap[pattern_idx];
        return mPattern.IsValid();
    }

    if (GRaceStatus::Exists()) {
        GRaceStatus &race = GRaceStatus::Get();
        if (race.GetPlayMode() == GRaceStatus::kPlayMode_Racing) {
            unsigned int race_pattern = race.GetTrafficPattern();
            if (race_pattern != 0) {
                SetTrafficPattern(race_pattern);
                return mPattern.IsValid();
            }
        }
    }
    UMath::Vector3 pattern_center = UMath::Vector3::kZero;

    float count = 0.0f;

    for (ITrafficCenter::List::const_iterator iter = ITrafficCenter::GetList().begin(); iter != ITrafficCenter::GetList().end(); ++iter) {
        ITrafficCenter *center = *iter;
        UMath::Vector3 velocity;
        UMath::Matrix4 matrix;

        if (center->GetTrafficBasis(matrix, velocity)) {
            UMath::Add(pattern_center, Vector4To3(matrix.v3), pattern_center);
            count += 1.0f;
        }
    }

    if (count > 0.0f) {
        Scale(pattern_center, 1.0f / count, pattern_center);
        bVector2 point(pattern_center.z, -pattern_center.x);

        TrackPathZone *zone = TheTrackPathManager.FindZone(&point, TRACK_PATH_ZONE_TRAFFIC_PATTERN, nullptr);
        if (zone) {
            // TODO
            SetTrafficPattern(mPatternMap.Find(zone->Data[0]));
        }
    }

    return mPattern.IsValid();
}

bool AITrafficManager::ValidateVehicle(IVehicle *ivehicle, float density) const {
    return true;
}

// float AITrafficManager::ComputeDensity() const {}

// TODO move?
static const float Tweak_TrafficDensitySpawnRates[11] = {0.0f, 0.05f, 0.1f, 0.125f, 0.2f, 0.4f, 0.6f, 1.0f, 3.0f, 5.0f, 8.0f};
static Table TrafficDensitySpawnRates(Tweak_TrafficDensitySpawnRates, 11, 0.0f, 1.0f);

void AITrafficManager::Update(float dT) {
    UpdateDebug();
    float density = ComputeDensity();

    if (density > 0.0f && ChoosePattern()) {
        float spawn_time = TrafficDensitySpawnRates.GetValue(density);
        for (int i = 0; i < 10u; i++) {
            mPatternTimer[i] += dT * spawn_time;
        }
        mNewInstanceTimer += dT;
        SpawnTraffic();
    }

    for (TrafficList::const_iterator iter = mVehicles.begin(); iter != mVehicles.end(); ++iter) {
        IVehicle *ivehicle = *iter;
        if (ivehicle->IsActive() && !ValidateVehicle(ivehicle, density)) {
            ivehicle->GetAIVehiclePtr()->UnSpawn();
        }
    }
}

void AITrafficManager::FlushAllTraffic(bool release) {
    for (TrafficList::const_iterator iter = mVehicles.begin(); iter != mVehicles.end(); ++iter) {
        IVehicle *ivehicle = *iter;
        if (release) {
            ISimable *isimable;
            if (ivehicle->QueryInterface(&isimable)) {
                isimable->Kill();
            }
        } else if (ivehicle->IsActive()) {
            ivehicle->GetAIVehiclePtr()->UnSpawn();
        }
    }

    if (release) {
        mVehicles.clear();
    }

    if (mPattern.IsValid()) {
        unsigned int num_types = mPattern.Num_Vehicles();
        for (unsigned int i = 0; i < num_types && i < 10; i++) {
            const TrafficPatternRecord &record = mPattern.Vehicles(i);
            mPatternTimer[i] = record.Rate * bRandom(1.0f);
        }
    }
}

bool AITrafficManager::OnTask(HSIMTASK htask, float dT) {
    ProfileNode profile_node("AITrafficManager::OnTask", 0);
    if (htask == mTask) {
        Update(dT);
        return true;
    }
    return false;
}

void AITrafficManager::OnDebugDraw() {}
